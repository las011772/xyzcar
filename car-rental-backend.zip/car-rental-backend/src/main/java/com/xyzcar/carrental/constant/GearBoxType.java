package com.xyzcar.carrental.constant;

public enum GearBoxType {
        MANUAL,
        AUTOMATIC
}
