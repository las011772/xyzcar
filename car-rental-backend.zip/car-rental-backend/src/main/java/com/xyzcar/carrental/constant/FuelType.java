package com.xyzcar.carrental.constant;

public enum FuelType {
        PETROL,
        DIESEL,
        LPG,
        ELECTRIC
}
