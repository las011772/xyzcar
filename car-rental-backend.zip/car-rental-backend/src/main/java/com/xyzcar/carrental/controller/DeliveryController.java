package com.xyzcar.carrental.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.xyzcar.carrental.domain.Car;
import com.xyzcar.carrental.service.DeliveryService;

@RestController
@RequiredArgsConstructor
public class DeliveryController {

        private final DeliveryService deliveryService;

        @PostMapping("/delivery")
        public Car pickUpTheCar(@RequestParam Long carId) {
                return deliveryService.pickUpTheCar(carId);
        }

}
