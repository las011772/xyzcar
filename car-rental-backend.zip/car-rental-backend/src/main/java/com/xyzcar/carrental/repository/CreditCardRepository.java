package com.xyzcar.carrental.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xyzcar.carrental.domain.CreditCard;

public interface CreditCardRepository extends JpaRepository<CreditCard, Long> {
}
