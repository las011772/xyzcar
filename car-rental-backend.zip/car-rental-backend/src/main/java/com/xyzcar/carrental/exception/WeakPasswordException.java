package com.xyzcar.carrental.exception;

public class WeakPasswordException extends RuntimeException {

        public WeakPasswordException(String message) {
                super(message);
        }

}
