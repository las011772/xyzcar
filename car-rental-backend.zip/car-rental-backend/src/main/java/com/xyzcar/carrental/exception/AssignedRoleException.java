package com.xyzcar.carrental.exception;

public class AssignedRoleException extends RuntimeException{

        public AssignedRoleException(String message) {
                super(message);
        }

}
