package com.xyzcar.carrental.dto;

import com.xyzcar.carrental.domain.CarParameters;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder
public class CarDto {

        private String registrationNr;
        private String brand;
        private String model;
        private Boolean isAvailable;

}
