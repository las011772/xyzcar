package com.xyzcar.carrental.exception;

public class NoAccessKeyException extends RuntimeException {

        public NoAccessKeyException(String message) {
                super(message);
        }

}
