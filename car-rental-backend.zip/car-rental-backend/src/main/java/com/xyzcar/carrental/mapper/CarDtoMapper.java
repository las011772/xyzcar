package com.xyzcar.carrental.mapper;

import org.springframework.stereotype.Service;

import com.xyzcar.carrental.domain.Car;
import com.xyzcar.carrental.dto.CarDto;

@Service
public class CarDtoMapper {

        public static Car mapToCar(CarDto carDto) {

                return Car.builder()
                        .registrationNr(carDto.getRegistrationNr())
                        .brand(carDto.getBrand())
                        .model(carDto.getModel())
                        .isAvailable(carDto.getIsAvailable())
                        .build();

        }

}
