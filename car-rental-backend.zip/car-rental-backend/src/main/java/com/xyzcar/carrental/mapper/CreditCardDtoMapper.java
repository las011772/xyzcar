package com.xyzcar.carrental.mapper;

import org.springframework.stereotype.Service;

import com.xyzcar.carrental.domain.CreditCard;
import com.xyzcar.carrental.dto.CreditCardDto;

@Service
public class CreditCardDtoMapper {

    public static CreditCard mapToCreditCard(CreditCardDto creditCardDto) {

        return CreditCard.builder()
                .cardNumber(creditCardDto.getCardNumber())
                .month(creditCardDto.getMonth())
                .year(creditCardDto.getYear())
                .CVV(creditCardDto.getCVV())
                .accountBalance(0L)
                .build();
    }

}
