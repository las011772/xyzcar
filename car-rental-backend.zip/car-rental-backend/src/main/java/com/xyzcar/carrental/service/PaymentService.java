package com.xyzcar.carrental.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import static com.xyzcar.carrental.mapper.CreditCardDtoMapper.mapToCreditCard;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xyzcar.carrental.domain.CreditCard;
import com.xyzcar.carrental.domain.User;
import com.xyzcar.carrental.dto.CreditCardDto;
import com.xyzcar.carrental.exception.NoCreditCardException;
import com.xyzcar.carrental.repository.CreditCardRepository;
import com.xyzcar.carrental.repository.UserRepository;
import com.xyzcar.carrental.security.LoggedInUser;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class PaymentService {

        private final UserRepository userRepository;
        private final CreditCardRepository creditCardRepository;
        private final LoggedInUser loggedInUser;

        public void addCreditCard(CreditCardDto creditCardDto) {

                log.info("Adding credit card to user");
                User user = loggedInUser.getUser();

                if(user.getCreditCard() != null) {

                        throw new IllegalCallerException("You Already Have Credit Card!");
                }
                CreditCard card = creditCardRepository.save(mapToCreditCard(creditCardDto));
                user.setCreditCard(card);
                card.setUser(user);
                userRepository.save(user);
        }

        public void moneyTransfer(Long moneyAmount) {

                User user = loggedInUser.getUser();

                if(user.getCreditCard() == null) {

                        throw new NoCreditCardException("You Do Not Have Credit Card!");

                } else {

                        log.info("Transfer for the amount of {}", moneyAmount);
                        CreditCard creditCard = user.getCreditCard();
                        creditCard.setAccountBalance(creditCard.getAccountBalance() + moneyAmount);
                        userRepository.save(user);

                }
        }

}
