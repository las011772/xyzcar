package com.xyzcar.carrental.mapper;

import org.springframework.stereotype.Service;

import com.xyzcar.carrental.domain.CarPackage;
import com.xyzcar.carrental.dto.CarPackageDto;

import java.util.ArrayList;

@Service
public class CarPackageDtoMapper {

        public static CarPackage mapToCarPackage(CarPackageDto carPackageDto) {

                return CarPackage.builder()
                        .packageName(carPackageDto.getPackageName())
                        .pricePerHour(carPackageDto.getPricePerHour())
                        .cars(new ArrayList<>())
                        .build();

        }

}
