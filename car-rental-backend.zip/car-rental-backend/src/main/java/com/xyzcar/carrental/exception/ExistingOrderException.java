package com.xyzcar.carrental.exception;

public class ExistingOrderException extends RuntimeException {

        public ExistingOrderException(String message) {
                super(message);
        }

}
