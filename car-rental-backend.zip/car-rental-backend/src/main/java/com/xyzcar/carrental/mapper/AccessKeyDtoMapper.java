package com.xyzcar.carrental.mapper;

import org.springframework.stereotype.Service;

import com.xyzcar.carrental.domain.AccessKey;
import com.xyzcar.carrental.dto.AccessKeyDto;

@Service
public class AccessKeyDtoMapper {

        public static AccessKeyDto mapToAccessKeyDto(AccessKey accessKey) {
                return AccessKeyDto.builder()
                        .id(accessKey.getId())
                        .carPackage(accessKey.getCarPackage())
                        .hours(accessKey.getHours())
                        .build();
        }

}
