package com.xyzcar.carrental.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xyzcar.carrental.domain.PlacedOrder;

public interface OrderRepository extends JpaRepository<PlacedOrder, Long> {}
