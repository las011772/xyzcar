package com.xyzcar.carrental.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.xyzcar.carrental.dto.CreditCardDto;
import com.xyzcar.carrental.service.PaymentService;

@RestController
@RequiredArgsConstructor
public class PaymentController {

        private final PaymentService paymentService;

        @PostMapping("/payment/addCreditCard")
        public void addCreditCard(@RequestBody CreditCardDto creditCardDto) {
                paymentService.addCreditCard(creditCardDto);
        }

        @PutMapping("/payment/moneyTransfer")
        public void moneyTransfer(@RequestParam Long moneyAmount) {
                paymentService.moneyTransfer(moneyAmount);
        }

}
