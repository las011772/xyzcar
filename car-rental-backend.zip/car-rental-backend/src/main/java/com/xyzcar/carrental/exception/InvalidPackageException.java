package com.xyzcar.carrental.exception;

public class InvalidPackageException extends RuntimeException {

        public InvalidPackageException(String message) {
                super(message);
        }

}
