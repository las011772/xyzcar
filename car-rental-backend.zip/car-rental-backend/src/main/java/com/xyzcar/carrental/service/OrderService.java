package com.xyzcar.carrental.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.xyzcar.carrental.domain.AccessKey;
import com.xyzcar.carrental.domain.CarPackage;
import com.xyzcar.carrental.domain.PlacedOrder;
import com.xyzcar.carrental.domain.User;
import com.xyzcar.carrental.dto.AccessKeyDto;
import com.xyzcar.carrental.exception.ExistingOrderException;
import com.xyzcar.carrental.exception.InsufficientFundsException;
import com.xyzcar.carrental.exception.NoCreditCardException;
import com.xyzcar.carrental.repository.AccessKeyRepository;
import com.xyzcar.carrental.repository.CarPackageRepository;
import com.xyzcar.carrental.repository.OrderRepository;
import com.xyzcar.carrental.security.LoggedInUser;

import javax.persistence.EntityNotFoundException;

import static com.xyzcar.carrental.mapper.AccessKeyDtoMapper.mapToAccessKeyDto;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class OrderService {

        private final Long ID = null;
        private final CarPackageRepository carPackageRepository;
        private final OrderRepository orderRepository;
        private final AccessKeyRepository accessKeyRepository;
        private final LoggedInUser loggedInUser;

        public List<PlacedOrder> getOrders() {
                log.info("Fetching all orders");
                return orderRepository.findAll();
        }

        public AccessKeyDto submitOrder(String carPackage, Integer hours) {

                User user = loggedInUser.getUser();

                if(user.getCreditCard() == null) {

                        throw new NoCreditCardException("You Do Not Have Credit Card!");
                }
                if(user.getAccessKey() != null) {

                        throw new ExistingOrderException("You Have Already Placed An Order!");
                }
                Long money = user.getCreditCard().getAccountBalance();
                CarPackage carPackageSearch = carPackageRepository.findByPackageName(carPackage)
                        .orElseThrow(() -> new EntityNotFoundException("This Package Does Not Exists!"));
                Integer price = carPackageSearch.getPricePerHour();

                AccessKey accessKey;

                if (money < (long) price * hours) {

                        throw new InsufficientFundsException("You Do Not Have Enough Money!");
                } else {

                        user.getCreditCard().setAccountBalance(money - (long) price * hours);
                        accessKey = new AccessKey(ID, carPackage, hours, null);
                        accessKeyRepository.save(accessKey);
                        user.setAccessKey(accessKey);
                        accessKey.setUser(user);

                        log.info("You managed to rent a car!");

                }
                AccessKeyDto accessKeyDto = mapToAccessKeyDto(accessKey);
                return accessKeyDto;
        }

}
