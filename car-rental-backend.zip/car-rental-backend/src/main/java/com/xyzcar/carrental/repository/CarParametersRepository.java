package com.xyzcar.carrental.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.xyzcar.carrental.domain.CarParameters;

public interface CarParametersRepository extends JpaRepository<CarParameters, Long> {
}
