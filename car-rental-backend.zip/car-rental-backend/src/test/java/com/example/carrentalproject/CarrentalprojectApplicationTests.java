package com.example.carrentalproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrentalprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
